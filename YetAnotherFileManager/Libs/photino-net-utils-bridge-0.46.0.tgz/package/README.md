# @photino-net-utils/bridge

The `window.external` request/response bridge shared by the Photino front-ends, plus the global
`External` type declaration.

It is consumed as a local package, without a build step:

```json
{
  "dependencies": {
    "@photino-net-utils/bridge": "file:../../../PhotinoNETUtils/UserInterface"
  }
}
```

```ts
import {Native} from "@photino-net-utils/bridge";

const info = await Native.request<{version: string}>("app.info");

const off = Native.on((message) => {
    if (message.type === "app.navigate") console.log(message.data);
});
```

`Native.available` is false in a plain browser, so UI code can fall back to browser behaviour
during `npm run dev` without the desktop host.

## Binary data

`DataClient` reads the host's binary data plane. The app names the bridge message that returns the
local server's base URL; the client keeps it for the life of the page.

```ts
import {DataClient} from "@photino-net-utils/bridge";

const data = new DataClient({baseMessage: "app.data"});

const page = await data.readBlock("/files?from=0&count=200");
const bytes = await data.bytes("/image/42");
const url = await data.image("/image/42"); // for <img src={url}/>
```

`readBlock` decodes `DataBlock`: text and number columns plus metadata. Large blocks are decoded
asynchronously in chunks, so the frame is not held while thousands of rows are built.
`decodeDataBlock` and `readDataBlock` are exported for callers that already have the `ArrayBuffer`
or the base URL.

## Settings

The four standard settings messages, so an app does not repeat the same `Native.request` calls:

```ts
import {
    loadSettings,
    loadSettingsDefaults,
    resetSettings,
    saveSettings,
} from "@photino-net-utils/bridge";

const current = await loadSettings<SettingsView>();
const stored = await saveSettings<SettingsView>(changes);
const restored = await resetSettings<SettingsView>();
const defaults = await loadSettingsDefaults<AppSettings>(); // asked once and remembered
```

The host fills in the defaults and the ranges, so the interface keeps no copy of either: a section's
reset merges only the keys it owns from `loadSettingsDefaults`. Every call rejects when the page runs
without the host (`npm run dev` in a plain browser), so a development build keeps its own placeholder.

## Logging

`Log` sends lines to the host's Serilog pipeline. In a browser it writes to the console instead.

```ts
import {Log} from "@photino-net-utils/bridge";

Log.info("folder opened", {path});
Log.error("thumbnail failed", {path, error});

const files = Log.child("file-list");
files.warn("too many entries", {count});
```

The host writes one structured event with the level, message, source and optional JSON context. The
bridge's own warnings use the same channel, so a malformed or unhandled message reaches the app log.

## Markdown

`Markdown` renders a GitHub release body, or any other Markdown, as HTML. The result is sanitized
with DOMPurify before it reaches the DOM, because the text comes from a release rather than from
the app. The class you pass styles the elements:

```tsx
import {Markdown} from "@photino-net-utils/bridge";

<div className="changelog">
    <Markdown source={release.notes}/>
</div>
```

## Scripts

The build steps every front-end in this family repeats live under `scripts/` in this package, so
an app only names them in its own `package.json`:

```json
{
  "scripts": {
    "prebuild": "node node_modules/@photino-net-utils/bridge/scripts/generate-code.mjs",
    "build": "tsc -b && vite build && node node_modules/@photino-net-utils/bridge/scripts/copy-build.mjs",
    "attributions": "node node_modules/@photino-net-utils/bridge/scripts/generate-attributions.mjs"
  }
}
```

All three are run from the app's `UserInterface` directory and resolve their paths from it.

- **copy-build.mjs** replaces `../Resources/wwwroot` with the Vite `build` output.
- **generate-code.mjs** regenerates `src/api/i18n.generated.ts` from the translation catalogue in
  `../Resources/i18n/en.jsonc` with the CodeGen binary under `../Libs/CodeGen/<rid>`.
- **generate-attributions.mjs** writes `src/data/attributions.ts` with every project the app ships:
  npm packages from `node_modules`, NuGet packages from the `PackageReference` entries and their
  nuspec, Rust crates from every `Cargo.lock`, and whatever `attributions.config.json` adds.

### attributions.config.json

Optional, next to the app's `package.json`. `extras` lists files the app ships but no package
manager knows about; `licences` overrides a package whose nuspec declares nothing. `project`
names a csproj other than the only one in the app directory.

```json
{
  "extras": [
    {"name": "7-Zip", "version": "25.01", "license": "LGPL-2.1-or-later with unRAR restriction", "file": "../Native/licenses/7-Zip.txt"}
  ],
  "licences": {
    "Some.Package": "https://example.com/LICENSE.txt"
  }
}
```

Licence texts that had to be downloaded are cached under `UserInterface/scripts/licenses/` in the
app, which is committed, so later runs and other machines work offline.
